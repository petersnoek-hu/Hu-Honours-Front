import React from "react";
import { SafeAreaView, Text } from "react-native";

const Chat = () => {
  return (
    <SafeAreaView className="flex-1">
        <Text>Chat</Text>
    </SafeAreaView>
  );
};

export default Chat;
