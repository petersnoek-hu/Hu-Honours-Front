import React from "react";
import { SafeAreaView, Text } from "react-native";

const Notifications= () => {
  return (
    <SafeAreaView className="flex-1">
        <Text>Meldingen</Text>
    </SafeAreaView>
  );
};

export default Notifications;
